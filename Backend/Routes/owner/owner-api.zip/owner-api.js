const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient();

const VEHICLES_TABLE = process.env.VEHICLES_TABLE || 'franchise-vehicles';

exports.lambdaHandler = async (event) => {
    const path = event.path || '/';
    const httpMethod = event.httpMethod || 'UNKNOWN';
    const pathParts = path.split('/');
    const queryParams = event.queryStringParameters || {};
    const headers = event.headers || {};
    const body = event.body || '{}';

    // Handle CORS preflight requests
    if (httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: getCorsHeaders(),
            body: ''
        };
    }

    let bodyJson = {};
    try {
        bodyJson = JSON.parse(body);
    } catch (e) {
        console.log('Invalid JSON body:', e);
    }

    // Extract user info from JWT token
    const userInfo = extractUserInfo(headers);
    
    if (!userInfo.isAuthenticated) {
        return {
            statusCode: 401,
            headers: getCorsHeaders(),
            body: JSON.stringify({
                error: 'Unauthorized',
                message: 'Valid JWT token required'
            })
        };
    }

    if (!userInfo.isOwner) {
        return {
            statusCode: 403,
            headers: getCorsHeaders(),
            body: JSON.stringify({
                error: 'Forbidden',
                message: 'Owner access required'
            })
        };
    }

    let responseBody;
    
    try {
        responseBody = await handleVehicleRequest(pathParts, httpMethod, queryParams, bodyJson, userInfo);
        
        return {
            statusCode: 200,
            headers: getCorsHeaders(),
            body: JSON.stringify(responseBody, null, 2),
        };
    } catch (error) {
        console.error('Error handling request:', error);
        
        return {
            statusCode: error.statusCode || 500,
            headers: getCorsHeaders(),
            body: JSON.stringify({
                error: error.name || 'InternalServerError',
                message: error.message || 'An unexpected error occurred'
            })
        };
    }
};

function extractUserInfo(headers) {
    try {
        const authHeader = headers.Authorization || headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return { isAuthenticated: false };
        }

        const token = authHeader.replace('Bearer ', '');
        const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
        
        const userId = payload.sub;
        const email = payload.email;
        const groups = payload['cognito:groups'] || [];
        
        const isOwner = groups.includes('owners') || groups.includes('admins') || groups.includes('franchise-operators');
        const isAdmin = groups.includes('admins');
        
        return {
            isAuthenticated: true,
            userId: userId,
            email: email,
            groups: groups,
            isOwner: isOwner,
            isAdmin: isAdmin,
            role: isAdmin ? 'admin' : (isOwner ? 'owner' : 'user')
        };
    } catch (error) {
        console.error('Error extracting user info:', error);
        return { isAuthenticated: false };
    }
}

async function handleVehicleRequest(pathParts, method, queryParams, body, userInfo) {
    const endpoint = pathParts.length > 2 ? pathParts[2] : null;
    const vehicleId = pathParts.length > 3 ? pathParts[3] : null;

    if (endpoint === 'vehicles') {
        switch (method) {
            case 'GET':
                if (vehicleId) {
                    return await getVehicle(vehicleId, userInfo);
                } else {
                    return await getAllVehicles(userInfo, queryParams);
                }
            
            case 'POST':
                return await createVehicle(body, userInfo);
            
            case 'PUT':
                if (!vehicleId) {
                    throw { statusCode: 400, message: 'Vehicle ID is required for updates' };
                }
                return await updateVehicle(vehicleId, body, userInfo);
            
            case 'DELETE':
                if (!vehicleId) {
                    throw { statusCode: 400, message: 'Vehicle ID is required for deletion' };
                }
                return await deleteVehicle(vehicleId, userInfo);
            
            default:
                throw { statusCode: 405, message: `Method ${method} not allowed` };
        }
    } else {
        throw { statusCode: 404, message: 'Endpoint not found' };
    }
}

async function getAllVehicles(userInfo, queryParams) {
    const params = {
        TableName: VEHICLES_TABLE,
        FilterExpression: 'ownerId = :ownerId',
        ExpressionAttributeValues: {
            ':ownerId': userInfo.userId
        }
    };

    if (queryParams.status) {
        params.FilterExpression += ' AND #status = :status';
        params.ExpressionAttributeValues[':status'] = queryParams.status;
        params.ExpressionAttributeNames = { '#status': 'status' };
    }

    if (queryParams.type) {
        params.FilterExpression += ' AND vehicleType = :type';
        params.ExpressionAttributeValues[':type'] = queryParams.type;
    }

    const result = await dynamodb.scan(params).promise();
    
    return {
        success: true,
        vehicles: result.Items,
        count: result.Items.length,
        message: 'Vehicles retrieved successfully'
    };
}

async function getVehicle(vehicleId, userInfo) {
    const params = {
        TableName: VEHICLES_TABLE,
        Key: {
            vehicleId: vehicleId,
            ownerId: userInfo.userId
        }
    };

    const result = await dynamodb.get(params).promise();
    
    if (!result.Item) {
        throw { statusCode: 404, message: 'Vehicle not found' };
    }

    return {
        success: true,
        vehicle: result.Item,
        message: 'Vehicle retrieved successfully'
    };
}

async function createVehicle(vehicleData, userInfo) {
    const requiredFields = ['vehicleType', 'model', 'accessCode', 'hourlyRate', 'batteryLife'];
    for (const field of requiredFields) {
        if (!vehicleData[field]) {
            throw { statusCode: 400, message: `${field} is required` };
        }
    }

    const existingVehicle = await checkAccessCodeExists(vehicleData.accessCode, userInfo.userId);
    if (existingVehicle) {
        throw { statusCode: 409, message: 'Access code already exists for your vehicles' };
    }

    const vehicleId = generateVehicleId();
    const timestamp = new Date().toISOString();

    const vehicle = {
        vehicleId: vehicleId,
        ownerId: userInfo.userId,
        ownerEmail: userInfo.email,
        vehicleType: vehicleData.vehicleType,
        model: vehicleData.model,
        accessCode: vehicleData.accessCode.toUpperCase(),
        hourlyRate: parseFloat(vehicleData.hourlyRate),
        batteryLife: parseInt(vehicleData.batteryLife),
        
        features: vehicleData.features || {
            heightAdjustment: false,
            gpsTracking: true,
            antiTheft: true,
            ledLights: false,
            phoneHolder: false,
            bluetooth: false,
            speedModes: false
        },
        
        discountCode: vehicleData.discountCode ? vehicleData.discountCode.toUpperCase() : null,
        discountPercentage: vehicleData.discountPercentage ? parseInt(vehicleData.discountPercentage) : 0,
        
        status: vehicleData.status || 'available',
        location: vehicleData.location || null,
        lastMaintenance: vehicleData.lastMaintenance || null,
        
        createdAt: timestamp,
        updatedAt: timestamp,
        totalRides: 0,
        totalRevenue: 0
    };

    const params = {
        TableName: VEHICLES_TABLE,
        Item: vehicle,
        ConditionExpression: 'attribute_not_exists(vehicleId)'
    };

    await dynamodb.put(params).promise();

    return {
        success: true,
        vehicle: vehicle,
        message: 'Vehicle created successfully'
    };
}

async function updateVehicle(vehicleId, updateData, userInfo) {
    const existingVehicle = await getVehicle(vehicleId, userInfo);
    
    if (updateData.accessCode && updateData.accessCode !== existingVehicle.vehicle.accessCode) {
        const existingWithCode = await checkAccessCodeExists(updateData.accessCode, userInfo.userId, vehicleId);
        if (existingWithCode) {
            throw { statusCode: 409, message: 'Access code already exists for your vehicles' };
        }
    }

    const timestamp = new Date().toISOString();
    
    let updateExpression = 'SET updatedAt = :updatedAt';
    let expressionAttributeValues = {
        ':updatedAt': timestamp
    };

    const updatableFields = [
        'model', 'accessCode', 'hourlyRate', 'batteryLife', 'status', 
        'discountCode', 'discountPercentage', 'location', 'lastMaintenance'
    ];

    updatableFields.forEach(field => {
        if (updateData[field] !== undefined) {
            updateExpression += `, ${field} = :${field}`;
            let value = updateData[field];
            
            if (field === 'hourlyRate') value = parseFloat(value);
            else if (field === 'batteryLife' || field === 'discountPercentage') value = parseInt(value);
            else if (field === 'accessCode' || field === 'discountCode') value = value ? value.toUpperCase() : value;
            
            expressionAttributeValues[`:${field}`] = value;
        }
    });

    if (updateData.features) {
        updateExpression += ', features = :features';
        expressionAttributeValues[':features'] = updateData.features;
    }

    const params = {
        TableName: VEHICLES_TABLE,
        Key: {
            vehicleId: vehicleId,
            ownerId: userInfo.userId
        },
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: 'ALL_NEW'
    };

    const result = await dynamodb.update(params).promise();

    return {
        success: true,
        vehicle: result.Attributes,
        message: 'Vehicle updated successfully'
    };
}

async function deleteVehicle(vehicleId, userInfo) {
    const vehicle = await getVehicle(vehicleId, userInfo);
    
    if (vehicle.vehicle.status === 'rented') {
        throw { statusCode: 400, message: 'Cannot delete vehicle that is currently rented' };
    }

    const params = {
        TableName: VEHICLES_TABLE,
        Key: {
            vehicleId: vehicleId,
            ownerId: userInfo.userId
        },
        ReturnValues: 'ALL_OLD'
    };

    const result = await dynamodb.delete(params).promise();

    if (!result.Attributes) {
        throw { statusCode: 404, message: 'Vehicle not found' };
    }

    return {
        success: true,
        deletedVehicle: result.Attributes,
        message: 'Vehicle deleted successfully'
    };
}

async function checkAccessCodeExists(accessCode, ownerId, excludeVehicleId = null) {
    const params = {
        TableName: VEHICLES_TABLE,
        FilterExpression: 'ownerId = :ownerId AND accessCode = :accessCode',
        ExpressionAttributeValues: {
            ':ownerId': ownerId,
            ':accessCode': accessCode.toUpperCase()
        }
    };

    if (excludeVehicleId) {
        params.FilterExpression += ' AND vehicleId <> :excludeVehicleId';
        params.ExpressionAttributeValues[':excludeVehicleId'] = excludeVehicleId;
    }

    const result = await dynamodb.scan(params).promise();
    return result.Items.length > 0;
}

function generateVehicleId() {
    return 'vehicle_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
}

function getCorsHeaders() {
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
    };
}